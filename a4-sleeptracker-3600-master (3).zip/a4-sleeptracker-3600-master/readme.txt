--Readme document for eric estrada erice4@uci.edu 87128480

1. How many assignment points do you believe you completed (replace the *'s with your numbers)?

9.5/10
- 1/1 The ability to log overnight sleep
- 1/1 The ability to log sleepiness during the day
- 1/1 The ability to view these two categories of logged data
- 2/2 Either using a native device resource or backing up logged data
- 2/2 Following good principles of mobile design
- 1.5/2 Creating a compelling app
- 1/1 A readme and demo video which explains how these features were implemented and their design rationale

2. How long, in hours, did it take you to complete this assignment?
This assignment took me around 25 hours to complete due to trail and error.


3. What online resources did you consult when completing this assignment? (list specific URLs)
When looking for how to do certain things I used the ionic website. This is all I used to figure out how to use the segment tabs and range chooser
and of course the modals

https://ionicframework.com/docs/


4. What classmates or other individuals did you consult as part of this assignment? What did you discuss?
I talked to a classmate named Ivan but only about design ideas that I didn't end up incorporating


5. Is there anything special we need to know in order to run your code?
You will need to download ionic storage angular to have the feature to save the data you used


--Aim for no more than two sentences for each of the following questions.--


6. Did you design your app with a particular type of user in mind? If so, whom?
No I just wanted to make it a simple app to use


7. Did you design your app specifically for iOS or Android, or both?
I did for both so they should be able to work good for both


8. How can a person log overnight sleep in your app? Why did you choose to support logging overnight sleep in this way?
to log a overnight sleep I have a change button that onced clicked will allow you to mark the day and time you fell asleep and woke up.
I did it this way because I felt like it was a simple way to do it.


9. How can a person log sleepiness during the day in your app? Why did you choose to support logging sleepiness in this way?
I have a ionic range bar that allows you to move the bar to select how tired you are. This was a simple way to mark how sleepy you are without
having to add counter measures if someone goes over the limit.


10. How can a person view the data they logged in your app? Why did you choose to support viewing logged data in this way?
so when you click the view data tab you see two segments on the top, one being sleepiness data and the other being overnight data. From here
you just click on whichever tab to see the data from that tab/


11. Which feature choose--using a native device resource, backing up logged data, or both?
I chose backing up logged data so the user can see what they put in after.


12. If you used a native device resource, what feature did you add? How does this feature change the app's experience for a user?
I didn't implement this.


13. If you backed up logged data, where does it back up to?
it backs up to the ionic storage.

14. How does your app implement or follow principles of good mobile design?
Yes because I added fail safe implemenetations to help the user plus I have a simple yet effective app design.
Also I made error preventions
